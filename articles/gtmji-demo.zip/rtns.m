rtns;
ci1(tvexpr,javaString,jbytearrayexpr,bigDecimal) ; Call-in from CI.java. All parameters are I. See f1 entry in ci.tab.
	write "Inside f1:",!
	zwrite
	write "----------------------",!
	set tvexpr=1,javaString=2,jbytearrayexpr=3,bigDecimal=4
	quit 5.678

ci2(intexpr,longexpr,floatexpr,expr,javaByteArray) ; Call-in from CI.java. All parameters are IO. See f2 entry in ci.tab.
	write "Inside f2:",!
	zwrite
	write "----------------------",!
	set intexpr=123,longexpr=234,floatexpr=345,expr="567",javaByteArray=$char(54)_$char(55)_$char(56)
	quit

co  ; Calls out to CO.java.
	set tvexpr=0,intexpr=123,longexpr=456,floatexpr=789
	set doubleexpr=1011,expr="GT.M expression",jbytearray="1415"
	set class="com/fis/gtm/ji/examples/CO"  ; Full classname.
	write "Before f1 and f2:",!
	zwrite
	write "----------------------",!
	do &examples.f1(class,"co1",intexpr,longexpr,doubleexpr,expr,jbytearray)
	hang 1 ; Sleep for output synchronization between M and Java.
	write "After f1 but before f2:",!
	zwrite
	write "----------------------",!
	set ret=$&examples.f2(class,"co2",.tvexpr,.floatexpr,.expr,.jbytearray)
	hang 1 ; Sleep for output synchronization between M and Java.
	write "After f1 and f2:",!
	zwrite
	write "----------------------",!
	quit
