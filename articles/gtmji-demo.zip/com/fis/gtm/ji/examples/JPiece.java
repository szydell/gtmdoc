/*
 * JPiece.java demonstrates a way to use GT.M Java call-in interface. It invokes two-, three-,
 * and four-argument forms of $PIECE().
 *
 * No claim of copyright is made with respect to this code. Please ensure that you have a correctly
 * configured installations for GT.M and Java, correctly configured environment variables, with
 * appropriate directories and files.
 *
 * DO NOT USE THIS CODE AS-IS IN A PRODUCTION ENVIRONMENT.
 *
 * JPiece.java is a part of gtmji-demo.zip, which has the following structure:
 *
 *   gtmji-demo.zip
 *   |-- ci.tab (#)
 *   |-- co.tab
 *   |-- com
 *   |   `-- fis
 *   |       `-- gtm
 *   |           `-- ji
 *   |               `-- examples
 *   |                   |-- CI.java
 *   |                   |-- CO.java
 *   |                   |-- gtmpack
 *   |                   |   `-- GTMFunctions.java (#)
 *   |                   `-- JPiece.java (#)
 *   |-- jpiece.m (#)
 *   `-- rtns.m
 *
 *   (#) are files needed to compile and run the JPiece class.
 *
 * This program is intended to be compatible with versions of GT.M V6.0-002 and higher on
 * Ubuntu 12.04 (64-bit), Ubuntu 12.10 (32-bit), SuSE Linux (64-bit), AIX 6.1 and 7.1, and SunOS 9 and 10.
 *
 * It was built and tested with OpenJDK 1.6 and GT.M V6.0-002 on Ubuntu 11.04 using the following commands:
 *
 *   export gtm_dist=/usr/lib/fis-gtm/V6.0-002_x86_64
 *   export gtmji_dir=<gtmji_directory>				# Specify the directory with built GTMJI libraries.
 *   								  For example, gtm_dist/plugin.
 *   mkdir -p $HOME/gtmji-demo					# Create an appropriate target directory.
 *   unzip GTMCIDemo.zip -d $HOME/gtmji-demo			# Extract gtmji-demo.zip to the target directory.
 *   cd $HOME/gtmji-demo
 *   export JAVA_HOME=/usr/lib/jvm/java				# Top directory of your Java installation.
 *   export GTMCI=$HOME/gtmji-demo/ci.tab			# Location of the call-in table ci.tab.
 *   export LD_LIBRARY_PATH=$gtm_dist:$gtmji_dir
 *   export gtmroutines="$HOME/gtmji-demo $gtm_dist"
 *   export CLASSPATH=$gtmji_dir/gtmji.jar:$HOME/gtmji-demo
 *   $JAVA_HOME/bin/javac com/fis/gtm/ji/examples/gtmpack/GTMFunctions.java
 *   $JAVA_HOME/bin/javac com/fis/gtm/ji/examples/JPiece.java
 *   $JAVA_HOME/bin/java com.fis.gtm.ji.examples.JPiece
 *
 * The expected result of running this program is as follows:
 *
 *   C
 *   GT.M
 *   Java
 *
 * After running this program, you might need to type
 *
 *   stty sane
 *
 * to restore the terminal settings due to a known GT.M issue (GTM-5632).
 *
 * This program is only a demonstration.
 */
package com.fis.gtm.ji.examples;

import com.fis.gtm.ji.examples.gtmpack.GTMFunctions;

public class JPiece {
	public static void main(String[] args) {
		// alphabetically organized list of some popular programming languages
		String popularProgramming = "C:GT.M:Java";
		String pieceSeperator = ":";
		// call-in to GT.M to invoke $piece("C:GT.M:Java",":")
		String twoArguments = GTMFunctions.piece(popularProgramming, pieceSeperator);
		// call-in to GT.M to invoke $piece("C:GT.M:Java",":",2)
		String threeArguments = GTMFunctions.piece(popularProgramming, pieceSeperator, 2);
		// call-in to GT.M invoke $piece("C:GT.M:Java",":",3,3)
		String fourArguments = GTMFunctions.piece(popularProgramming, pieceSeperator, 3, 3);
		System.out.println(twoArguments);
		System.out.println(threeArguments);
		System.out.println(fourArguments);
	}
}
