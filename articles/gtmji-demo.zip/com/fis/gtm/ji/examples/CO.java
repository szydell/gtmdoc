/*
 * CO.java contains static methods co1 and co2 which are called from co^rtns (GT.M).

 * No claim of copyright is made with respect to this code. Please ensure that you have a correctly
 * configured installations for GT.M and Java, correctly configured environment variables, with
 * appropriate directories and files.
 *
 * DO NOT USE THIS CODE AS-IS IN A PRODUCTION ENVIRONMENT.
 *
 * CO.java is a part of gtmji-demo.zip, which as the following structure:
 *
 *   gtmji-demo.zip
 *   |-- ci.tab
 *   |-- co.tab (#)
 *   |-- com
 *   |   `-- fis
 *   |       `-- gtm
 *   |           `-- ji
 *   |               `-- examples
 *   |                   |-- CI.java
 *   |                   |-- CO.java (#)
 *   |                   |-- gtmpack
 *   |                   |   `-- GTMFunctions.java
 *   |                   `-- JPiece.java
 *   |-- jpiece.m
 *   `-- rtns.m  (#)
 *
 *   (#) are files needed to compile the CO class and run co^rtns.
 *
 * This program is intended to be compatible with versions of GT.M V6.0-002 and higher on
 * Ubuntu 12.04 (64-bit), Ubuntu 12.10 (32-bit), SuSE Linux (64-bit), AIX 6.1 and 7.1, and SunOS 9 and 10.
 *
 * It was built and tested with OpenJDK 1.6 and GT.M V6.0-002 on Ubuntu 11.04 using the following commands:
 *
 *   export gtm_dist=/usr/lib/fis-gtm/V6.0-002_x86_64/
 *   export gtmji_dir=<gtmji_directory>				# Specify the directory with built GTMJI libraries.
 *   								  For example, $gtm_dist/plugin. Be sure to specify
 *   								  this path in co.tab file in place of <gtmji_dir>.
 *   mkdir -p $HOME/gtmji-demo					# Create an appropriate target directory.
 *   unzip GTMCIDemo.zip -d $HOME/gtmji-demo			# Extract gtmji-demo.zip to the target directory.
 *   cd $HOME/gtmji-demo
 *   export JAVA_HOME=/usr/lib/jvm/java/			# Top directory of your Java installation.
 *   export JAVA_SO_HOME=$JAVA_HOME/jre/lib/amd64 		# Directory that contains libjava.so.
 *   export JVM_SO_HOME=$JAVA_HOME/jre/lib/amd64/server/ 	# Directory that contains libjvm.so.
 *   export GTMXC_examples=$HOME/gtmji-demo/co.tab 		# Location of the call-out table.
 *   export LD_LIBRARY_PATH=$JAVA_SO_HOME:$JVM_SO_HOME:$gtmji_dir:$gtm_dist
 *   export gtmroutines="$HOME/gtmji-demo $gtm_dist"
 *   export CLASSPATH=$gtmji_dir/gtmji.jar:$HOME/gtmji-demo
 *   export GTMXC_classpath=$gtmji_dir/gtmji.jar:$HOME/gtmji-demo/
 *   $JAVA_HOME/bin/javac com/fis/gtm/ji/examples/CO.java
 *   $gtm_dist/mumps -run co^rtns 				# The co^rtns label calls out to the co1 and co2
 *								  static methods of CO class.
 *
 * The expected result of running this program is as follows (":" indicates Java output and "=" indicates
 * GT.M output):
 *
 *   In co1():
 *   intexpr: 123
 *   longexpr: 456
 *   doubleexpr: 1011.0
 *   javaString: GT.M expression
 *   javaByteArray: 1415
 *   ----------------------
 *   Before f1 and f2:
 *   class="com/fis/ji/examples/CO"
 *   doubleexpr=1011
 *   expr="GT.M expression"
 *   floatexpr=789
 *   intexpr=123
 *   jbytearray=1415
 *   longexpr=456
 *   tvexpr=0
 *   ----------------------
 *   In xcallIO():
 *   tvexpr: false
 *   floatexpr: 789.0
 *   expr: GT.M expression
 *   gtmbytearrayexpr: 1415
 *   ----------------------
 *   After f1 but before f2:
 *   class="com/fis/gtm/ji/examples/CO"
 *   doubleexpr=1011
 *   expr="GT.M expression"
 *   floatexpr=789
 *   intexpr=123
 *   jbytearray=1415
 *   longexpr=456
 *   tvexpr=0
 *   ----------------------
 *   After f1 and f2:
 *   class="com/fis/gtm/ji/examples/CO"
 *   doubleexpr=1011
 *   expr="GT.M expression modified in CO.co2"
 *   floatexpr=3.141
 *   intexpr=123
 *   jbytearray=589
 *   longexpr=456
 *   ret=321
 *   tvexpr=1
 *
 * After running this program, you might need to type
 *
 *   stty sane
 *
 * to restore the terminal settings due to a known GT.M issue (GTM-5632).
 *
 * This program is only a demonstration.
 */
package com.fis.gtm.ji.examples;

import com.fis.gtm.ji.GTMBoolean;
import com.fis.gtm.ji.GTMByteArray;
import com.fis.gtm.ji.GTMCI;
import com.fis.gtm.ji.GTMDouble;
import com.fis.gtm.ji.GTMFloat;
import com.fis.gtm.ji.GTMInteger;
import com.fis.gtm.ji.GTMLong;
import com.fis.gtm.ji.GTMString;

public class CO {
	public static void co1(Object[] args) {
		GTMInteger intexpr = (GTMInteger)args[0];
		GTMLong longexpr = (GTMLong)args[1];
		GTMDouble doubleexpr = (GTMDouble)args[2];
		String javaString = (String)args[3];
		byte[] javaByteArray = (byte[])args[4];

		System.out.println(
			"In co1():\n" +
			"intexpr: " + intexpr + "\n" +
			"longexpr: " + longexpr + "\n" +
			"doubleexpr: " + doubleexpr + "\n" +
			"javaString: " + javaString + "\n" +
			"javaByteArray: " + new String(javaByteArray) + "\n" +
			"----------------------");

		intexpr.value = 3;
		longexpr.value = 141;
		doubleexpr.value = 5.926;
		javaString = "GT.M expression modified in CO.co1";
		javaByteArray[0] = (byte)51;
	}

	public static long co2(Object[] args) {
		GTMBoolean tvexpr = (GTMBoolean)args[0];
		GTMFloat floatexpr = (GTMFloat)args[1];
		GTMString expr = (GTMString)args[2];
		GTMByteArray gtmbytearrayexpr = (GTMByteArray)args[3];

		System.out.println(
			"In xcallIO():\n" +
			"tvexpr: " + tvexpr + "\n" +
			"floatexpr: " + floatexpr + "\n" +
			"expr: " + expr + "\n" +
			"gtmbytearrayexpr: " + gtmbytearrayexpr + "\n" +
			"----------------------");

		tvexpr.value = true;
		floatexpr.value = 3.141f;
		expr.value = expr.value + " modified in CO.co2";
		gtmbytearrayexpr.value = new byte[]{53, 56, 57};

		return 321;
	}
}
