/*
 * GTMFunctions.java contains static methods to invoke the two-, three-, and four-argument forms of $PIECE().
 * GTMFunctions.java is intended to be used with JPiece.java.
 *
 * No claim of copyright is made with respect to this code. Please ensure that you have a correctly
 * configured installations for GT.M and Java, correctly configured environment variables, with
 * appropriate directories and files.
 *
 * DO NOT USE THIS CODE AS-IS IN A PRODUCTION ENVIRONMENT.
 *
 * CI.java is a part of gtmji-demo.zip, which has the following structure:
 *
 *   gtmji-demo.zip
 *   |-- ci.tab (#)
 *   |-- co.tab
 *   |-- com
 *   |   `-- fis
 *   |       `-- gtm
 *   |           `-- ji
 *   |               `-- examples
 *   |                   |-- CI.java
 *   |                   |-- CO.java
 *   |                   |-- gtmpack
 *   |                   |   `-- GTMFunctions.java (#)
 *   |                   `-- JPiece.java (#)
 *   |-- jpiece.m (#)
 *   `-- rtns.m
 *
 *   (#) are files needed to compile and run JPiece.java.
 *
 * For instructions on using GTMFunctions, see JPiece.java.
 */
package com.fis.gtm.ji.examples.gtmpack;

import com.fis.gtm.ji.GTMCI;
import com.fis.gtm.ji.GTMInteger;
import com.fis.gtm.ji.GTMString;

public class GTMFunctions {
	/* The format of GT.M's $PIECE function is $P[IECE](expr1,expr2[,intexpr1[,intexpr2]]). The following
	 * three functions are testing invocations with two, three, and four arguments, in that order.
	 */

	/* A two-argument wrapper for $PIECE. Returns the first piece of str1 as delimited by str2. */
	public static String piece(String str1, String str2) {
		GTMString expr1 = new GTMString(str1);
		GTMString expr2 = new GTMString(str2);
		String result = null;
		try {
			// invoke the M function which piece2args entry in the call-in table maps to
			result = GTMCI.doStringJob("piece2args", expr1, expr2);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/* A three-argument wrapper for $PIECE. Returns the pnum-th piece of str1 as delimited by str2. */
	public static String piece(String str1, String str2, Integer pnum) {
		GTMString expr1 = new GTMString(str1);
		GTMString expr2 = new GTMString(str2);
		GTMInteger intexpr1 = new GTMInteger(pnum);
		String result = null;
		try {
			// invoke the M function which piece3args entry in the call-in table maps to
			result = GTMCI.doStringJob("piece3args", expr1, expr2, intexpr1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/* A four-argument wrapper for $PIECE. Returns pieces of str1 as delimited by str2, starting with pnum-th
	 * and ending with lastpnum-th piece. */
	public static String piece(String str1, String str2, Integer pnum, Integer lastpnum) {
		GTMString expr1 = new GTMString(str1);
		GTMString expr2 = new GTMString(str2);
		GTMInteger intexpr1 = new GTMInteger(pnum);
		GTMInteger intexpr2 = new GTMInteger(lastpnum);
		String result = null;
		try {
			// invoke the M function which piece4args entry in the call-in table maps to
			result = GTMCI.doStringJob("piece4args", expr1, expr2, intexpr1, intexpr2);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}
