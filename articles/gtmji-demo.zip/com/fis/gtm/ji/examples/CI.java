/*
 * CI.java demonstrates a way to call into GT.M from Java with various I/IO parameters.
 *
 * No claim of copyright is made with respect to this code. Please ensure that you have a correctly
 * configured installations for GT.M and Java, correctly configured environment variables, with
 * appropriate directories and files.
 *
 * DO NOT USE THIS CODE AS-IS IN A PRODUCTION ENVIRONMENT.
 *
 * CI.java is a part of gtmji-demo.zip, which has the following structure:
 *
 *   gtmji-demo.zip
 *   |-- ci.tab (#)
 *   |-- co.tab
 *   |-- com
 *   |   `-- fis
 *   |       `-- gtm
 *   |           `-- ji
 *   |               `-- examples
 *   |                   |-- CI.java (#)
 *   |                   |-- CO.java
 *   |                   |-- gtmpack
 *   |                   |   `-- GTMFunctions.java
 *   |                   `-- JPiece.java
 *   |-- jpiece.m
 *   `-- rtns.m  (#)
 *
 *   (#) are files needed to compile and run the CI class.
 *
 * This program is intended to be compatible with versions of GT.M V6.0-002 and higher on
 * Ubuntu 12.04 (64-bit), Ubuntu 12.10 (32-bit), SuSE Linux (64-bit), AIX 6.1 and 7.1, and SunOS 9 and 10.
 *
 * It was built and tested with OpenJDK 1.6 and GT.M V6.0-002 on Ubuntu 11.04 using the following commands:
 *
 *   export gtm_dist=/usr/lib/fis-gtm/V6.0-002_x86_64/
 *   export gtmji_dir=<gtmji_directory>			# Specify the directory with built GTMJI libraries.
 *   							  For example, $gtm_dist/plugin.
 *   mkdir -p $HOME/gtmji-demo				# Create an appropriate target directory.
 *   unzip gtmji-demo.zip -d $HOME/gtmji-demo		# Extract gtmji-demo.zip to the target directory.
 *   cd $HOME/gtmji-demo
 *   export JAVA_HOME=/usr/lib/jvm/java			# Top directory of your Java installation.
 *   export GTMCI=$HOME/gtmji-demo/ci.tab		# Location of the call-in table ci.tab.
 *   export LD_LIBRARY_PATH=$gtm_dist:$gtmji_dir
 *   export gtmroutines="$HOME/gtmji-demo $gtm_dist"
 *   export CLASSPATH=$gtmji_dir/gtmji.jar:$HOME/gtmji-demo
 *   $JAVA_HOME/bin/javac com/fis/gtm/ji/examples/CI.java
 *   $JAVA_HOME/bin/java com.fis.gtm.ji.examples.CI
 *
 * The expected result of running this program is as follows (":" indicates Java output and "=" indicates
 * GT.M output):
 *
 *   Before f1 and f2:
 *   tvexpr: false
 *   intexpr: 3
 *   longexpr: 3141
 *   floatexpr: 3.141
 *   doubleexpr: 3.1415926535
 *   expr: GT.M String Value
 *   jbytearrayexpr: 3141
 *   javaString: Java String Value
 *   javaByteArray: 3142
 *   bigDecimal: 3.14159265358979323846
 *   ----------------------
 *   Inside f1:
 *   bigDecimal="3.14159265358979323846"
 *   javaString="Java String Value"
 *   jbytearrayexpr=3141
 *   tvexpr=0
 *   ----------------------
 *   After f1 but before f2:
 *   tvexpr: false
 *   intexpr: 3
 *   longexpr: 3141
 *   floatexpr: 3.141
 *   doubleexpr: 3.1415926535
 *   expr: GT.M String Value
 *   jbytearrayexpr: 3141
 *   javaString: Java String Value
 *   javaByteArray: 3142
 *   bigDecimal: 3.14159265358979323846
 *   doubleReturnValue: 5.678
 *   ----------------------
 *   Inside f2:
 *   expr="GT.M String Value" ;*
 *   floatexpr=3.141 ;*
 *   intexpr=3 ;*
 *   javaByteArray=3142 ;*
 *   longexpr=3141 ;*
 *   ----------------------
 *   After f1 and f2:
 *   tvexpr: false
 *   intexpr: 123
 *   longexpr: 234
 *   floatexpr: 345.0
 *   doubleexpr: 3.1415926535
 *   expr: 567
 *   jbytearrayexpr: 3141
 *   javaString: Java String Value
 *   javaByteArray: 6782
 *   bigDecimal: 3.14159265358979323846
 *
 * After running this program, you might need to type
 *
 *   stty sane
 *
 * to restore the terminal settings due to a known GT.M issue (GTM-5632).
 *
 * This program is only a demonstration.
 */
package com.fis.gtm.ji.examples;

import java.math.BigDecimal;

import com.fis.gtm.ji.GTMBoolean;
import com.fis.gtm.ji.GTMByteArray;
import com.fis.gtm.ji.GTMCI;
import com.fis.gtm.ji.GTMDouble;
import com.fis.gtm.ji.GTMFloat;
import com.fis.gtm.ji.GTMInteger;
import com.fis.gtm.ji.GTMLong;
import com.fis.gtm.ji.GTMString;

public class CI {
	public static void main(String[] args) {
		try {
			boolean booleanValue = false;
			int intValue = 3;
			long longValue = 3141L;
			float floatValue = 3.141f;
			double doubleValue = 3.1415926535;
			String exprValue = "GT.M String Value";
			String javaStringValue = "Java String Value";
			String jbytearrayexprValue = new String(new byte[]{51, 49, 52, 49});
			String javaByteArrayValue = new String(new byte[]{51, 49, 52, 50});
			String bigDecimalValue = "3.14159265358979323846";

			GTMBoolean tvexpr = new GTMBoolean(booleanValue);
			GTMInteger intexpr = new GTMInteger(intValue);
			GTMLong longexpr = new GTMLong(longValue);
			GTMFloat floatexpr = new GTMFloat(floatValue);
			GTMDouble doubleexpr = new GTMDouble(doubleValue);
			GTMString expr = new GTMString(exprValue);
			GTMByteArray jbytearrayexpr = new GTMByteArray(jbytearrayexprValue.getBytes());
			String javaString = javaStringValue;
			byte[] javaByteArray = javaByteArrayValue.getBytes();
			BigDecimal bigDecimal = new BigDecimal(bigDecimalValue);

			System.out.println(
				"Before f1 and f2:\n" +
				"tvexpr: " + tvexpr + "\n" +
				"intexpr: " + intexpr + "\n" +
				"longexpr: " + longexpr + "\n" +
				"floatexpr: " + floatexpr + "\n" +
				"doubleexpr: " + doubleexpr + "\n" +
				"expr: " + expr + "\n" +
				"jbytearrayexpr: " + jbytearrayexpr + "\n" +
				"javaString: " + javaString + "\n" +
				"javaByteArray: " + new String(javaByteArray) + "\n" +
				"bigDecimal: " + bigDecimal + "\n" +
				"----------------------");

			double doubleReturnValue = GTMCI.doDoubleJob(
				"f1",
				tvexpr,
				javaString,
				jbytearrayexpr,
				bigDecimal);

			Thread.sleep(1000); // for synchronization of the output

			System.out.println(
				"After f1 but before f2:\n" +
				"tvexpr: " + tvexpr + "\n" +
				"intexpr: " + intexpr + "\n" +
				"longexpr: " + longexpr + "\n" +
				"floatexpr: " + floatexpr + "\n" +
				"doubleexpr: " + doubleexpr + "\n" +
				"expr: " + expr + "\n" +
				"jbytearrayexpr: " + jbytearrayexpr + "\n" +
				"javaString: " + javaString + "\n" +
				"javaByteArray: " + new String(javaByteArray) + "\n" +
				"bigDecimal: " + bigDecimal + "\n" +
				"doubleReturnValue: " + doubleReturnValue + "\n" +
				"----------------------");

			GTMCI.doVoidJob(
				"f2",
				intexpr,
				longexpr,
				floatexpr,
				expr,
				javaByteArray);

			Thread.sleep(1000); // for synchronization of the output

			System.out.println(
				"After f1 and f2:\n" +
				"tvexpr: " + tvexpr + "\n" +
				"intexpr: " + intexpr + "\n" +
				"longexpr: " + longexpr + "\n" +
				"floatexpr: " + floatexpr + "\n" +
				"doubleexpr: " + doubleexpr + "\n" +
				"expr: " + expr + "\n" +
				"jbytearrayexpr: " + jbytearrayexpr + "\n" +
				"javaString: " + javaString + "\n" +
				"javaByteArray: " + new String(javaByteArray) + "\n" +
				"bigDecimal: " + bigDecimal + "\n");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
