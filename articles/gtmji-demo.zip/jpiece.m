jpiece;
args2(str,delim)
	quit $piece(str,delim)
args3(str,delim,start)
	quit $piece(str,delim,start)
args4(str,delim,start,end)
	quit $piece(str,delim,start,end)
